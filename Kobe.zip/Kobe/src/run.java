import javax.swing.JOptionPane;


public class run {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
JOptionPane.showMessageDialog(null, "I have no idea what i'm doing");
int option =(JOptionPane.showConfirmDialog(null, "do you like my project?"));
if(option==0){
	JOptionPane.showMessageDialog(null, "you better.");
}
else{
	JOptionPane.showMessageDialog(null, "Here is filler for Ms. Taric's lack of imagination");
}
JOptionPane.showMessageDialog(null, "Mr. Taric says you're pretty cool");
	}

}
